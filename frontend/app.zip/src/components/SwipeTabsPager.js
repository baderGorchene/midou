import React, { useEffect, useMemo, useRef } from "react";
import { Animated, Dimensions, StyleSheet, View } from "react-native";
import { Gesture, GestureDetector } from "react-native-gesture-handler";

export default function SwipeTabsPager({
  routes,
  activeRouteName,
  onChangeRouteName,
  renderRoute,
  disabled,
}) {
  const width = Dimensions.get("window").width;

  const pages = useMemo(() => {
    return (routes || []).map((name) => ({ name }));
  }, [routes]);

  const activeIndex = Math.max(
    0,
    pages.findIndex((p) => p.name === activeRouteName),
  );

  const translateX = useRef(new Animated.Value(-activeIndex * width)).current;
  const lastIndexRef = useRef(activeIndex);

  useEffect(() => {
    Animated.spring(translateX, {
      toValue: -activeIndex * width,
      damping: 26,
      stiffness: 190,
      mass: 0.9,
      useNativeDriver: true,
    }).start();

    lastIndexRef.current = activeIndex;
  }, [activeIndex, width, translateX]);

  const gesture = useMemo(() => {
    const MIN_DISTANCE = 40; 

    return Gesture.Pan()
      .enabled(!disabled)
      .onBegin(() => {
        translateX.stopAnimation();
      })
      .onUpdate((e) => {
        if (Math.abs(e.translationX) < 2) return;
        if (Math.abs(e.translationX) < Math.abs(e.translationY) * 1.2) return;

        translateX.setValue(-activeIndex * width + e.translationX);
      })
      .onEnd((e) => {
        const nextByDistance =
          e.translationX < -MIN_DISTANCE
            ? activeIndex + 1
            : e.translationX > MIN_DISTANCE
              ? activeIndex - 1
              : activeIndex;

        const nextIndex = Math.max(0, Math.min(pages.length - 1, nextByDistance));
        if (nextIndex !== lastIndexRef.current) {
          const nextRouteName = pages[nextIndex]?.name;
          if (nextRouteName) onChangeRouteName?.(nextRouteName);
        } else {
          Animated.spring(translateX, {
            toValue: -activeIndex * width,
            damping: 26,
            stiffness: 190,
            mass: 0.9,
            useNativeDriver: true,
          }).start();
        }
      });
  }, [disabled, activeIndex, width, pages, onChangeRouteName, translateX]);

  return (
    <GestureDetector gesture={gesture}>
      <Animated.View style={[styles.pager, { width }]}>
        <Animated.View
          style={{
            flexDirection: "row",
            width: width * Math.max(1, pages.length),
            transform: [{ translateX }],
          }}
        >
          {pages.map((p) => (
            <View key={p.name} style={{ width, flex: 0 }}>
              {renderRoute(p.name)}
            </View>
          ))}
        </Animated.View>
      </Animated.View>
    </GestureDetector>
  );
}

const styles = StyleSheet.create({
  pager: {
    flex: 1,
    overflow: "hidden",
  },
});

