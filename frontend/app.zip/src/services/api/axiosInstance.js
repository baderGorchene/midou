import axios from "axios";
import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const API_HOST = "192.168.1.12"; // e.g. '192.168.1.10' for real device
const getBaseUrl = () => {
  if (!__DEV__) return "https://your-api-domain.com/api";
  if (API_HOST) return `http://${API_HOST}:5000/api`;
  return Platform.OS === "android"
    ? "http://10.0.2.2:5000/api"
    : "http://localhost:5000/api";
};
const BASE_URL = getBaseUrl();
console.log("API BASE URL:", BASE_URL);

const axiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: {
    "Content-Type": "application/json",
  },
});

axiosInstance.interceptors.request.use(
  async (config) => {
    try {
      const token = await AsyncStorage.getItem("userToken");
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    } catch (error) {
      console.error("Error getting token from storage:", error);
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  },
);

axiosInstance.interceptors.response.use(
  (response) => {
    return response.data;
  },
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401) {
      try {
        await AsyncStorage.removeItem("userToken");
        await AsyncStorage.removeItem("userData");
      } catch (storageError) {
        console.error("Error clearing storage:", storageError);
      }
    }

    if (!error.response) {
      error.message = "Erreur réseau. Veuillez vérifier votre connexion.";
    }

    console.log("AXIOS REAL ERROR:", {
      message: error?.message,
      status: error?.response?.status,
      data: error?.response?.data,
      url: error?.config?.url,
      baseURL: error?.config?.baseURL,
    });

    return Promise.reject({
      message:
        error.response?.data?.message ||
        error.message ||
        "Une erreur s'est produite",
      status: error.response?.status,
      data: error.response?.data,
      url: error?.config?.url,
      baseURL: error?.config?.baseURL,
    });
  },
);

axiosInstance.setAuthToken = async (token) => {
  if (token) {
    await AsyncStorage.setItem("userToken", token);
    axiosInstance.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  } else {
    await AsyncStorage.removeItem("userToken");
    delete axiosInstance.defaults.headers.common["Authorization"];
  }
};

axiosInstance.clearAuthToken = async () => {
  await AsyncStorage.removeItem("userToken");
  await AsyncStorage.removeItem("userData");
  delete axiosInstance.defaults.headers.common["Authorization"];
};

export default axiosInstance;
