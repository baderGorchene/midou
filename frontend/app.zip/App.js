import React, { useCallback, useMemo } from "react";
import {
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
} from "@expo-google-fonts/inter";
import {
  NavigationContainer,
  useNavigation,
  useFocusEffect,
} from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import {
  View,
  ActivityIndicator,
  Text,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
} from "react-native";

import { ThemeProvider, useTheme } from "./src/context/ThemeContext";
import {
  NotificationsProvider,
  useNotifications,
} from "./src/context/NotificationsContext";
import { AuthProvider, useAuth } from "./src/context/AuthContext";
import { typography } from "./src/theme/theme";

import LoginScreen from "./src/screens/LoginScreen";
import RegisterScreen from "./src/screens/RegisterScreen";
import DashboardScreen from "./src/screens/DashboardScreen";
import DeskScreen from "./src/screens/DeskScreen";
import RoomReservationScreen from "./src/screens/RoomReservationScreen";
import LeaveRequestScreen from "./src/screens/LeaveRequestScreen";
import EventsScreen from "./src/screens/EventsScreen";
import NotificationsScreen from "./src/screens/NotificationsScreen";
import ProfileScreen from "./src/screens/ProfileScreen";
import PendingRoomReservationsScreen from "./src/screens/PendingRoomReservationsScreen";
import PendingLeaveRequestsScreen from "./src/screens/PendingLeaveRequestScreen";
import ManageAnnouncementsScreen from "./src/screens/hr/ManageAnnouncementsScreen";
import ManageEventsScreen from "./src/screens/hr/ManageEventsScreen";
import DepartmentChannelScreen from "./src/screens/DepartmentChannelScreen";
import ApprovalsScreen from "./src/screens/approvals/ApprovalsScreen";
import UserManagementScreen from "./src/screens/admin/UserManagementScreen";
import SeatManagementScreen from "./src/screens/admin/SeatManagementScreen";
import AdminOfficeLayoutScreen from "./src/screens/admin/AdminOfficeLayoutScreen";
import SplashScreen from "./src/screens/SplashScreen";
import { DepartmentChannelProvider } from "./src/context/DepartmentChannelContext";
import { useDepartmentChannel } from "./src/context/DepartmentChannelContext";
import CustomBottomTabBar from "./src/components/CustomBottomTabBar";
import AnimatedTabScreen from "./src/components/AnimatedTabScreen";
import RoomManagementScreen from "./src/screens/admin/RoomManagementScreen";
import SwipeTabsPager from "./src/components/SwipeTabsPager";
import { GestureHandlerRootView } from "react-native-gesture-handler";


const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function HeaderActions() {
  const navigation = useNavigation();
  const { unreadCount } = useNotifications();
  const { colors } = useTheme();

  return (
    <View style={styles.headerActions}>
      <TouchableOpacity
        style={styles.headerIconButton}
        onPress={() => navigation.navigate("Notifications")}
      >
        <Ionicons
          name={unreadCount > 0 ? "notifications" : "notifications-outline"}
          size={22}
          color={colors.textPrimary}
        />
        {unreadCount > 0 ? <View style={styles.headerBadge} /> : null}
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.headerIconButton}
        onPress={() => navigation.navigate("Profile")}
      >
        <Ionicons
          name="person-circle-outline"
          size={26}
          color={colors.textPrimary}
        />
      </TouchableOpacity>
    </View>
  );
}

function HomeTabs() {
  const { colors } = useTheme();
  const { user } = useAuth();
  const { refreshChannelInfo } = useDepartmentChannel();

  useFocusEffect(
    useCallback(() => {
      refreshChannelInfo();
    }, [refreshChannelInfo]),
  );

  const role = user?.roleName ?? user?.roleId;

  const isAdmin = role === "Admin" || role === 3;
  const isHR = role === "HR" || role === 4;

  const canReviewRequests = isAdmin || isHR;

  const visibleSwipeRoutes = useMemo(() => {
    const base = ["Home"];
    if (!isAdmin) base.push("Channel");
    if (isAdmin) base.push("Announcements");
    if (canReviewRequests) base.push("Approvals");
    return base;
  }, [isAdmin, canReviewRequests]);

  return (

    <Tab.Navigator
      tabBar={(props) => <CustomBottomTabBar {...props} />}
      screenOptions={{
        headerShown: true,
        headerRight: () => <HeaderActions />,
        headerStyle: {
          backgroundColor: colors.surface,
        },
        headerTintColor: colors.textPrimary,
        headerTitleStyle: {
          fontWeight: typography.semibold,
          fontSize: typography.lg,
        },
        headerShadowVisible: false,
        sceneStyle: {
          backgroundColor: colors.background,
        },
        sceneContainerStyle: {
          backgroundColor: colors.background,
        },
        lazy: false,
      }}
    >
      <Tab.Screen name="Home" options={{ title: "Accueil" }}>
        {({ navigation }) => (
          <AnimatedTabScreen>
            <SwipeTabsPager
              routes={visibleSwipeRoutes}
              activeRouteName={
                navigation.getState().routes[navigation.getState().index].name
              }
              onChangeRouteName={(nextRouteName) =>
                navigation.navigate(nextRouteName)
              }
              renderRoute={(routeName) => {
                switch (routeName) {
                  case "Home":
                    return <DashboardScreen />;
                  case "Channel":
                    return <DepartmentChannelScreen />;
                  case "Announcements":
                    return <ManageAnnouncementsScreen />;
                  case "Approvals":
                    return <ApprovalsScreen />;
                  default:
                    return <DashboardScreen />;
                }
              }}
            />
          </AnimatedTabScreen>
        )}
      </Tab.Screen>


      {!isAdmin && (
        <Tab.Screen name="Channel" options={{ title: "Canal" }}>
          {() => (
            <AnimatedTabScreen>
              <DepartmentChannelScreen />
            </AnimatedTabScreen>
          )}
        </Tab.Screen>
      )}

      {isAdmin && (
        <Tab.Screen name="Announcements" options={{ title: "Annonces" }}>
          {() => (
            <AnimatedTabScreen>
              <ManageAnnouncementsScreen />
            </AnimatedTabScreen>
          )}
        </Tab.Screen>
      )}

      {canReviewRequests && (
        <Tab.Screen name="Approvals" options={{ title: "Approbations" }}>
          {() => (
            <AnimatedTabScreen>
              <ApprovalsScreen />
            </AnimatedTabScreen>
          )}
        </Tab.Screen>
      )}

      <Tab.Screen
        name="Desk"
        component={DeskScreen}
        options={{
          title: "Réservation Bureau",
          tabBarButton: () => null,
        }}
      />

      <Tab.Screen
        name="Rooms"
        component={RoomReservationScreen}
        options={{
          title: "Réservation Salle",
          tabBarButton: () => null,
        }}
      />

      <Tab.Screen
        name="Events"
        component={EventsScreen}
        options={{
          title: "Événements",
          tabBarButton: () => null,
        }}
      />
    </Tab.Navigator>
  );
}

function AppNavigator() {
  const { colors, darkMode } = useTheme();
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <View
        style={[
          styles.loadingContainer,
          { backgroundColor: colors.background },
        ]}
      >
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={[styles.loadingText, { color: colors.textSecondary }]}>
          Chargement…
        </Text>
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <NavigationContainer
        theme={{
          dark: darkMode,
          colors: {
            primary: colors.primary,
            background: colors.background,
            card: colors.surface,
            text: colors.textPrimary,
            border: colors.border,
            notification: colors.primary,
          },
        }}
      >
        <Stack.Navigator initialRouteName="Splash">
          {!isAuthenticated ? (
            <>
              <Stack.Screen
                name="Splash"
                component={SplashScreen}
                options={{ headerShown: false }}
              />
              <Stack.Screen name="Login" component={LoginScreen} />
              <Stack.Screen name="Register" component={RegisterScreen} />
            </>
          ) : (
            <>
              <Stack.Screen
                name="HomeTabs"
                component={HomeTabs}
                options={{ headerShown: false }}
              />

              <Stack.Screen
                name="LeaveRequest"
                component={LeaveRequestScreen}
                options={{ title: "Demandes Congé" }}
              />

              <Stack.Screen
                name="Notifications"
                component={NotificationsScreen}
                options={{ title: "Notifications" }}
              />

              <Stack.Screen
                name="Profile"
                component={ProfileScreen}
                options={{ title: "Profil" }}
              />

              <Stack.Screen
                name="PendingRoomReservations"
                component={PendingRoomReservationsScreen}
                options={{ title: "Demandes Salles En Attente" }}
              />

              <Stack.Screen
                name="ManageAnnouncements"
                component={ManageAnnouncementsScreen}
                options={{ title: "Gérer Annonces" }}
              />

              <Stack.Screen
                name="EventManagement"
                component={
                  require("./src/screens/admin/EventManagementScreen").default
                }
                options={{ title: "Gestion des Événements" }}
              />

              <Stack.Screen
                name="ManageEvents"
                component={ManageEventsScreen}
                options={{ title: "Créer un événement" }}
              />

              <Stack.Screen
                name="PendingLeaveRequests"
                component={PendingLeaveRequestsScreen}
                options={{ title: "Demandes Congé En Attente" }}
              />

              <Stack.Screen
                name="UserManagement"
                component={UserManagementScreen}
                options={{ title: "Gestion des Utilisateurs" }}
              />

              <Stack.Screen
                name="RoomManagement"
                component={RoomManagementScreen}
                options={{ title: "Gestion des Salles" }}
              />

              <Stack.Screen
                name="SeatManagement"
                component={SeatManagementScreen}
                options={{ title: "Tables et Sièges" }}
              />

              <Stack.Screen
                name="AdminOfficeLayout"
                component={AdminOfficeLayoutScreen}
                options={{ title: "Plan Interactif" }}
              />
            </>
          )}
        </Stack.Navigator>
      </NavigationContainer>
    </GestureHandlerRootView>
  );
}

function RootApp() {
  const { colors, darkMode } = useTheme();

  return (
    <>
      <StatusBar
        barStyle={darkMode ? "light-content" : "dark-content"}
        backgroundColor={colors.surface}
      />
      <AuthProvider>
        <NotificationsProvider>
          <DepartmentChannelProvider>
            <AppNavigator />
          </DepartmentChannelProvider>
        </NotificationsProvider>
      </AuthProvider>
    </>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  if (!fontsLoaded) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: "#F4F6F8" }]}>
        <ActivityIndicator size="large" color="#E11D48" />
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <RootApp />
      </ThemeProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    marginTop: 12,
    fontSize: typography.sm,
  },
  headerActions: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 8,
  },
  tabDot: {
    position: "absolute",
    top: -2,
    right: -4,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#ef4444",
    borderWidth: 2,
    borderColor: "#fff",
  },
  headerIconButton: {
    marginLeft: 14,
    position: "relative",
  },
  headerBadge: {
    position: "absolute",
    top: 1,
    right: 1,
    width: 8,
    height: 8,
    borderRadius: 999,
    backgroundColor: "#ef4444",
  },
  tabIconWrapper: {
    position: "relative",
    width: 28,
    alignItems: "center",
    justifyContent: "center",
  },
  tabBadge: {
    position: "absolute",
    top: -6,
    right: -12,
    minWidth: 18,
    height: 18,
    borderRadius: 999,
    backgroundColor: "#ef4444",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 4,
  },
  tabBadgeText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
  },
});
